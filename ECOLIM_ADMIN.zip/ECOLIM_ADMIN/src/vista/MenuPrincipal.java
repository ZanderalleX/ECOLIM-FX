package vista;

import modelo.Usuario;

import javax.swing.*;
import java.awt.*;

public class MenuPrincipal extends JFrame {

    private JPanel panelMenu;
    private JPanel panelContenido;
    private JLabel lblBienvenida;

    private JButton btnUsuarios;
    private JButton btnReportes;
    private JButton btnEstadisticas;
    private JButton btnUser;
    private JButton btnEntity;
    private JButton btnPlant;
    private JButton btnRol;
    private JButton btnPeople;
    // private JButton btnProcessFlow;
    private JButton btnType;
    private JButton btnCerrarSesion;

    private final Usuario admin;

    public MenuPrincipal(Usuario admin) {
        this.admin = admin;
        initComponents();
        setTitle("ECOLIM ADMIN");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Icono de la ventana / barra superior / barra de tareas
        ImageIcon iconApp = new ImageIcon(getClass().getResource("/imagenes/logoprincipal.png"));
        setIconImage(iconApp.getImage());

        mostrarPanel(new PanelUsuarios());
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        panelMenu = new JPanel(null);
        panelMenu.setPreferredSize(new Dimension(250, 0));
        panelMenu.setBackground(new Color(29, 185, 84));
        add(panelMenu, BorderLayout.WEST);

        // Logo superior del menú
        ImageIcon iconoLogo = new ImageIcon(getClass().getResource("/imagenes/logoprincipal.png"));
        Image imagenEscalada = iconoLogo.getImage().getScaledInstance(90, 90, Image.SCALE_SMOOTH);
        JLabel lblLogo = new JLabel(new ImageIcon(imagenEscalada));
        lblLogo.setBounds(80, 15, 90, 90);
        panelMenu.add(lblLogo);

        JLabel lblTitulo = new JLabel("ECOLIM ADMIN");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(20, 110, 210, 30);
        panelMenu.add(lblTitulo);

        String nombreCompleto = admin.getNombre() + " " + admin.getApellido();

        lblBienvenida = new JLabel("<html>Bienvenido<br><b>" + nombreCompleto + "</b></html>");
        lblBienvenida.setForeground(Color.WHITE);
        lblBienvenida.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblBienvenida.setBounds(25, 150, 200, 60);
        panelMenu.add(lblBienvenida);

        btnUsuarios = crearBoton("Usuarios", 240);
        // = crearBoton("Ubicaciones", 280);
        btnEstadisticas = crearBoton("Estadísticas", 320);
        btnUser = crearBoton("Usuario para empresa", 360);
        btnEntity = crearBoton("Empresas", 400);
        btnPlant = crearBoton("Planta", 440);
        btnRol = crearBoton("Roles", 480);
        btnPeople = crearBoton("Personas", 520);
        // btnProcessFlow = crearBoton("Flujo de precesos", 560);
        btnType = crearBoton("Tipos", 600);
        btnReportes = crearBoton("Reportes", 640);
        
        btnCerrarSesion = crearBoton("Cerrar sesión", 775);

        panelMenu.add(btnUsuarios);
        // panelMenu.add(btnUbicaciones);
        panelMenu.add(btnEstadisticas);
        panelMenu.add(btnUser);
        panelMenu.add(btnEntity);
        panelMenu.add(btnPlant);
        panelMenu.add(btnRol);
        panelMenu.add(btnPeople);
        // panelMenu.add(btnProcessFlow);
        panelMenu.add(btnType);
        panelMenu.add(btnReportes);
                
        panelMenu.add(btnCerrarSesion);

        panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBackground(new Color(245, 245, 245));
        add(panelContenido, BorderLayout.CENTER);

        btnUsuarios.addActionListener(e -> mostrarPanel(new PanelUsuarios()));
        // btnUbicaciones.addActionListener(e -> mostrarPanel(new PanelUbicaciones()));
        btnEstadisticas.addActionListener(e -> mostrarPanel(new PanelEstadisticas()));
        btnUser.addActionListener(e -> mostrarPanel(new PanelUsers()));
        btnEntity.addActionListener(e -> mostrarPanel(new PanelEntities()));
        btnPlant.addActionListener(e -> mostrarPanel(new PanelPlantas()));
        btnRol.addActionListener(e -> mostrarPanel(new PanelRoles()));
        btnPeople.addActionListener(e -> mostrarPanel(new PanelPeople()));
        // btnProcessFlow.addActionListener(e -> mostrarPanel(new PanelProcessFlows()));        
        btnType.addActionListener(e -> mostrarPanel(new PanelTypes()));
        btnReportes.addActionListener(e -> mostrarPanel(new PanelReportes()));
        
        btnCerrarSesion.addActionListener(e -> {
            new LoginAdmin().setVisible(true);
            dispose();
        });
    }

    private JButton crearBoton(String texto, int y) {
        JButton boton = new JButton(texto);
        boton.setBounds(20, y, 200, 30);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        boton.setBackground(Color.WHITE);
        boton.setForeground(new Color(29, 185, 84));
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return boton;
    }

    private void mostrarPanel(JPanel panelNuevo) {
        panelContenido.removeAll();
        panelContenido.add(panelNuevo, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }
}