package vista;

import dao.UserDAO;
import dao.EntityDAO;
import dao.PeopleDAO;

import modelo.User;
import modelo.Entity;
import modelo.People;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Stack;

public class PanelUsers extends JPanel {

    private JTable tabla;
    private DefaultTableModel modelo;

    private final UserDAO userDAO = new UserDAO();
    private final EntityDAO entityDAO = new EntityDAO();
    private final PeopleDAO peopleDAO = new PeopleDAO();

    private JTextField txtBuscar;
    private JComboBox<String> cbBuscarPor;

    private final Stack<User> pilaEliminados = new Stack<>();

    public PanelUsers() {

        initComponents();
        cargarUsuarios();
    }

    private void initComponents() {

        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));

        JLabel titulo = new JLabel("Gestión de User para Empresas", SwingConstants.CENTER);

        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setBorder(
                BorderFactory.createEmptyBorder(20, 0, 20, 0)
        );

        modelo = new DefaultTableModel(new Object[]{"ID", "Código", "Empresa", "Persona", "Usuario", "Rol", "Estado"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modelo);

        tabla.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(40);

        tabla.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(80);

        tabla.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(180);

        tabla.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(180);

        tabla.getColumnModel()
                .getColumn(4)
                .setPreferredWidth(150);

        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 14)
        );

        JPanel panelBusqueda = new JPanel();

        cbBuscarPor = new JComboBox<>(new String[]{
            "Código",
            "Usuario",
            "Rol",
            "Estado",
            "Empresa",
            "Persona"
        });

        txtBuscar = new JTextField(20);

        JButton btnBuscar = new JButton("Buscar");
        JButton btnMostrarTodos = new JButton("Mostrar Todos");

        btnBuscar.addActionListener(e -> buscarUsuarios());
        btnMostrarTodos.addActionListener(e -> cargarUsuarios());

        panelBusqueda.add(new JLabel("Buscar por:"));
        panelBusqueda.add(cbBuscarPor);

        panelBusqueda.add(new JLabel("Valor:"));
        panelBusqueda.add(txtBuscar);

        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnMostrarTodos);

        JPanel panelSuperior = new JPanel(
                new BorderLayout()
        );

        panelSuperior.add(
                titulo,
                BorderLayout.NORTH
        );

        panelSuperior.add(
                panelBusqueda,
                BorderLayout.SOUTH
        );

        add(
                panelSuperior,
                BorderLayout.NORTH
        );

        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();

        JButton btnAgregar = new JButton("Agregar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnEstado = new JButton("Activar / Desactivar");
        JButton btnDeshacer = new JButton("Deshacer Eliminación");

        btnAgregar.addActionListener(e -> agregarUsuario());
        btnModificar.addActionListener(e -> modificarUsuario());
        btnEliminar.addActionListener(e -> eliminarUsuario());
        btnEstado.addActionListener(e -> cambiarEstadoUsuario());
        btnDeshacer.addActionListener(e -> deshacerEliminacion());

        panelBotones.add(btnAgregar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnEstado);
        panelBotones.add(btnDeshacer);

        add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarUsuarios() {

        modelo.setRowCount(0);

        List<User> lista = userDAO.listUsers();

        for (User u : lista) {

            Entity entidad = null;
            People persona = null;

            if (u.getEntityId() != null) {
                entidad = entityDAO.findById(u.getEntityId());
            }

            if (u.getPersonId() != null) {
                persona = peopleDAO.findById(u.getPersonId());
            }

            modelo.addRow(new Object[]{
                u.getId(),
                u.getCode(),
                entidad != null
                ? entidad.getName()
                : "Sin empresa",
                persona != null
                ? persona.getFullName()
                : "Sin persona",
                u.getUsername(),
                u.isPrincipal()
                ? "Principal"
                : "Secundario",
                u.isStatus()
                ? "Activo"
                : "Inactivo"
            });
        }
    }

    private void buscarUsuarios() {

        String criterio
                = cbBuscarPor.getSelectedItem().toString();

        String texto
                = txtBuscar.getText().trim().toLowerCase();

        modelo.setRowCount(0);

        for (User u : userDAO.listUsers()) {

            Entity entidad = null;
            People persona = null;

            boolean coincide = false;

            switch (criterio) {

                case "ID" ->
                    coincide
                            = String.valueOf(u.getId())
                                    .contains(texto);

                case "Código" ->
                    coincide
                            = u.getCode() != null
                            && u.getCode()
                                    .toLowerCase()
                                    .contains(texto);

                case "Usuario" ->
                    coincide
                            = u.getUsername() != null
                            && u.getUsername()
                                    .toLowerCase()
                                    .contains(texto);

                case "Rol" ->
                    coincide
                            = (u.isPrincipal()
                                    ? "principal"
                                    : "secundario")
                                    .contains(texto);

                case "Estado" ->
                    coincide
                            = (u.isStatus()
                                    ? "activo"
                                    : "inactivo")
                                    .equals(texto);
                case "Empresa" ->
                    coincide = entidad != null
                            && entidad.getName() != null
                            && entidad.getName()
                                    .toLowerCase()
                                    .contains(texto);

                case "Persona" ->
                    coincide = persona != null
                            && persona.getFullName() != null
                            && persona.getFullName()
                                    .toLowerCase()
                                    .contains(texto);
            }

            if (coincide) {

                if (u.getEntityId() != null) {
                    entidad = entityDAO.findById(u.getEntityId());
                }

                if (u.getPersonId() != null) {
                    persona = peopleDAO.findById(u.getPersonId());
                }

                modelo.addRow(new Object[]{
                    u.getId(),
                    u.getCode(),
                    entidad != null
                    ? entidad.getName()
                    : "Sin empresa",
                    persona != null
                    ? persona.getFullName()
                    : "Sin persona",
                    u.getUsername(),
                    u.isPrincipal()
                    ? "Principal"
                    : "Secundario",
                    u.isStatus()
                    ? "Activo"
                    : "Inactivo"
                });
            }
        }
    }

    private void agregarUsuario() {

        JComboBox<Entity> cbEntity = new JComboBox<>();
        JComboBox<People> cbPeople = new JComboBox<>();

        for (Entity e : entityDAO.listEntities()) {
            cbEntity.addItem(e);
        }

        for (People p : peopleDAO.listPeople()) {
            cbPeople.addItem(p);
        }

        JTextField txtUsername = new JTextField();
        JPasswordField txtPassword = new JPasswordField();
        JPasswordField txtConfirmPassword = new JPasswordField();

        JComboBox<String> cbRol
                = new JComboBox<>(new String[]{"Principal", "Secundario"});

        Object[] campos = {
            "Empresa:", cbEntity,
            "Persona:", cbPeople,
            "Usuario:", txtUsername,
            "Contraseña:", txtPassword,
            "Confirmar contraseña:", txtConfirmPassword,
            "Rol:", cbRol,};

        int op = JOptionPane.showConfirmDialog(
                this,
                campos,
                "Agregar Usuario",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (op == JOptionPane.OK_OPTION) {

            Entity entidad
                    = (Entity) cbEntity.getSelectedItem();

            String password
                    = new String(txtPassword.getPassword());

            String confirmar
                    = new String(txtConfirmPassword.getPassword());

            if (password.trim().isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "La contraseña no puede estar vacía."
                );

                return;
            }

            if (!password.equals(confirmar)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Las contraseñas no coinciden."
                );

                return;
            }

            People persona
                    = (People) cbPeople.getSelectedItem();

            User u = new User();

            u.setEntityId(entidad.getId());
            u.setPersonId(persona.getId());

            u.setUsername(txtUsername.getText());
            u.setPassword(password);

            u.setPrincipal(
                    cbRol.getSelectedItem().equals("Principal")
            );

            u.setStatus(true);

            if (userDAO.insertUser(u)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Usuario agregado correctamente."
                );

                cargarUsuarios();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo agregar."
                );
            }
        }
    }

    private void modificarUsuario() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un usuario."
            );

            return;
        }

        long id = (long) modelo.getValueAt(fila, 0);

        User u = userDAO.findById(id);

        if (u == null) {
            return;
        }

        JComboBox<Entity> cbEntity = new JComboBox<>();
        JComboBox<People> cbPeople = new JComboBox<>();

        for (Entity e : entityDAO.listEntities()) {

            cbEntity.addItem(e);

            if (u.getEntityId() != null
                    && e.getId() == u.getEntityId()) {

                cbEntity.setSelectedItem(e);
            }
        }

        for (People p : peopleDAO.listPeople()) {

            cbPeople.addItem(p);

            if (u.getPersonId() != null
                    && p.getId() == u.getPersonId()) {

                cbPeople.setSelectedItem(p);
            }
        }

        JTextField txtUsername
                = new JTextField(u.getUsername());

        JPasswordField txtPassword
                = new JPasswordField(u.getPassword());

        JComboBox<String> cbRol
                = new JComboBox<>(new String[]{"Principal", "Secundario"});

        cbRol.setSelectedItem(
                u.isPrincipal() ? "Principal" : "Secundario"
        );

        Object[] campos = {
            "Empresa:", cbEntity,
            "Persona:", cbPeople,
            "Usuario:", txtUsername,
            "Contraseña:", txtPassword,
            "Rol:", cbRol,};

        int op = JOptionPane.showConfirmDialog(
                this,
                campos,
                "Modificar Usuario",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (op == JOptionPane.OK_OPTION) {

            Entity entidad
                    = (Entity) cbEntity.getSelectedItem();

            People persona
                    = (People) cbPeople.getSelectedItem();

            u.setEntityId(entidad.getId());
            u.setPersonId(persona.getId());

            u.setUsername(txtUsername.getText());
            u.setPassword(
                    new String(txtPassword.getPassword())
            );

            u.setPrincipal(
                    cbRol.getSelectedItem().equals("Principal")
            );

            if (userDAO.updateUser(u)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Usuario actualizado."
                );

                cargarUsuarios();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo actualizar."
                );
            }
        }
    }

    private void cambiarEstadoUsuario() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un usuario."
            );

            return;
        }

        long id = (long) modelo.getValueAt(fila, 0);

        User u = userDAO.findById(id);

        if (u == null) {
            return;
        }

        String accion = u.isStatus()
                ? "desactivar"
                : "activar";

        int op = JOptionPane.showConfirmDialog(
                this,
                "¿Está seguro de " + accion + " este usuario?",
                "Confirmar",
                JOptionPane.YES_NO_OPTION
        );

        if (op == JOptionPane.YES_OPTION) {

            u.setStatus(!u.isStatus());

            if (userDAO.updateUser(u)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Estado actualizado correctamente."
                );

                cargarUsuarios();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo actualizar el estado."
                );
            }
        }
    }

    private void eliminarUsuario() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(this,
                    "Seleccione un usuario.");

            return;
        }

        long id = (long) modelo.getValueAt(fila, 0);

        int op = JOptionPane.showConfirmDialog(
                this,
                "¿Eliminar usuario?",
                "Confirmar",
                JOptionPane.YES_NO_OPTION
        );

        if (op == JOptionPane.YES_OPTION) {
            User usuarioEliminado
                    = userDAO.findById(id);

            if (usuarioEliminado != null) {

                pilaEliminados.push(usuarioEliminado);
            }

            if (userDAO.deleteUser(id)) {

                JOptionPane.showMessageDialog(this,
                        "Usuario eliminado.");

                cargarUsuarios();

            } else {

                JOptionPane.showMessageDialog(this,
                        "No se pudo eliminar.");
            }
        }
    }

    private void deshacerEliminacion() {

        if (pilaEliminados.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "No hay usuarios eliminados para recuperar."
            );

            return;
        }

        User u = pilaEliminados.pop();

        if (userDAO.insertUser(u)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Usuario recuperado correctamente."
            );

            cargarUsuarios();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "No se pudo recuperar el usuario."
            );
        }
    }
}
