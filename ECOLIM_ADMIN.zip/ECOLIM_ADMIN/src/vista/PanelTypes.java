package vista;

import dao.TypeDAO;
import modelo.Type;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelTypes extends JPanel {

    private JTable tabla;
    private DefaultTableModel modelo;

    private final TypeDAO typeDAO =
            new TypeDAO();

    public PanelTypes() {

        initComponents();
        cargarTipos();
    }

    private void initComponents() {

        setLayout(new BorderLayout());

        setBackground(
                new Color(245, 245, 245)
        );

        JLabel titulo = new JLabel(
                "Gestión de Tipos",
                SwingConstants.CENTER
        );

        titulo.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        28
                )
        );

        titulo.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        0,
                        20,
                        0
                )
        );

        add(titulo, BorderLayout.NORTH);

        modelo = new DefaultTableModel(
                new Object[]{
                        "ID",
                        "Categoría",
                        "Código",
                        "Nombre",
                        "Descripción",
                        "Estado"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(
                    int row,
                    int column
            ) {
                return false;
            }
        };

        tabla = new JTable(modelo);

        tabla.setRowHeight(25);

        add(
                new JScrollPane(tabla),
                BorderLayout.CENTER
        );

        JPanel panelBotones = new JPanel();

        JButton btnAgregar =
                new JButton("Agregar");

        JButton btnModificar =
                new JButton("Modificar");

        JButton btnEliminar =
                new JButton("Eliminar");

        btnAgregar.addActionListener(
                e -> agregarTipo()
        );

        btnModificar.addActionListener(
                e -> modificarTipo()
        );

        btnEliminar.addActionListener(
                e -> eliminarTipo()
        );

        panelBotones.add(btnAgregar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);

        add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarTipos() {

        modelo.setRowCount(0);

        List<Type> lista =
                typeDAO.listTypes();

        for (Type t : lista) {

            modelo.addRow(new Object[]{
                    t.getId(),
                    t.getCategory(),
                    t.getCode(),
                    t.getName(),
                    t.getDescripcion(),
                    t.isStatus()
                            ? "Activo"
                            : "Inactivo"
            });
        }
    }

    private void agregarTipo() {

        JTextField txtCategory =
                new JTextField();

        JTextField txtCode =
                new JTextField();

        JTextField txtName =
                new JTextField();

        JTextField txtDescripcion =
                new JTextField();

        JTextArea txtAdditional =
                new JTextArea(5, 20);

        JCheckBox chkStatus =
                new JCheckBox("Activo");

        Object[] campos = {
                "Categoría:", txtCategory,
                "Código:", txtCode,
                "Nombre:", txtName,
                "Descripción:", txtDescripcion,
                "Additional Fields JSON:",
                new JScrollPane(txtAdditional),
                "Estado:", chkStatus
        };

        int op = JOptionPane.showConfirmDialog(
                this,
                campos,
                "Agregar Tipo",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (op == JOptionPane.OK_OPTION) {

            Type t = new Type();

            t.setCategory(
                    txtCategory.getText().trim()
            );

            t.setCode(
                    txtCode.getText().trim()
            );

            t.setName(
                    txtName.getText().trim()
            );

            t.setDescripcion(
                    txtDescripcion.getText().trim()
            );

            t.setAdditionalFields(
                    txtAdditional.getText().trim()
            );

            t.setStatus(
                    chkStatus.isSelected()
            );

            if (typeDAO.insertType(t)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Tipo agregado correctamente."
                );

                cargarTipos();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo agregar."
                );
            }
        }
    }

    private void modificarTipo() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un tipo."
            );

            return;
        }

        long id = (long)
                modelo.getValueAt(fila, 0);

        Type t = typeDAO.findById(id);

        if (t == null) {
            return;
        }

        JTextField txtCategory =
                new JTextField(
                        t.getCategory()
                );

        JTextField txtCode =
                new JTextField(
                        t.getCode()
                );

        JTextField txtName =
                new JTextField(
                        t.getName()
                );

        JTextField txtDescripcion =
                new JTextField(
                        t.getDescripcion()
                );

        JTextArea txtAdditional =
                new JTextArea(
                        t.getAdditionalFields()
                );

        JCheckBox chkStatus =
                new JCheckBox(
                        "Activo",
                        t.isStatus()
                );

        Object[] campos = {
                "Categoría:", txtCategory,
                "Código:", txtCode,
                "Nombre:", txtName,
                "Descripción:", txtDescripcion,
                "Additional Fields JSON:",
                new JScrollPane(txtAdditional),
                "Estado:", chkStatus
        };

        int op = JOptionPane.showConfirmDialog(
                this,
                campos,
                "Modificar Tipo",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (op == JOptionPane.OK_OPTION) {

            t.setCategory(
                    txtCategory.getText().trim()
            );

            t.setCode(
                    txtCode.getText().trim()
            );

            t.setName(
                    txtName.getText().trim()
            );

            t.setDescripcion(
                    txtDescripcion.getText().trim()
            );

            t.setAdditionalFields(
                    txtAdditional.getText().trim()
            );

            t.setStatus(
                    chkStatus.isSelected()
            );

            if (typeDAO.updateType(t)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Tipo actualizado."
                );

                cargarTipos();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo actualizar."
                );
            }
        }
    }

    private void eliminarTipo() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un tipo."
            );

            return;
        }

        long id = (long)
                modelo.getValueAt(fila, 0);

        int op = JOptionPane.showConfirmDialog(
                this,
                "¿Eliminar tipo?",
                "Confirmar",
                JOptionPane.YES_NO_OPTION
        );

        if (op == JOptionPane.YES_OPTION) {

            if (typeDAO.deleteType(id)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Tipo eliminado."
                );

                cargarTipos();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo eliminar."
                );
            }
        }
    }
}