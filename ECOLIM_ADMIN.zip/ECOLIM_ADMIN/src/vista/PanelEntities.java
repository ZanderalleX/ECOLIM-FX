package vista;

import dao.EntityDAO;
import modelo.Entity;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelEntities extends JPanel {

    private JTable tabla;
    private DefaultTableModel modelo;

    private final EntityDAO entityDAO = new EntityDAO();

    public PanelEntities() {

        initComponents();
        cargarEntidades();
    }

    private void initComponents() {

        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));

        JLabel titulo = new JLabel(
                "Gestión de Empresas",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setBorder(
                BorderFactory.createEmptyBorder(20, 0, 20, 0)
        );

        add(titulo, BorderLayout.NORTH);

        modelo = new DefaultTableModel(
                new Object[]{
                    "ID",
                    "Código",
                    "Nombre",
                    "Dirección",
                    "Teléfono",
                    "Tipo",
                    "Estado"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modelo);

        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 14)
        );

        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();

        JButton btnAgregar = new JButton("Agregar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");

        btnAgregar.addActionListener(e -> agregarEntidad());
        btnModificar.addActionListener(e -> modificarEntidad());
        btnEliminar.addActionListener(e -> eliminarEntidad());

        panelBotones.add(btnAgregar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);

        add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarEntidades() {

        modelo.setRowCount(0);

        List<Entity> lista = entityDAO.listEntities();

        for (Entity e : lista) {

            modelo.addRow(new Object[]{
                e.getId(),
                e.getCode(),
                e.getName(),
                e.getAddress(),
                e.getPhone(),
                e.getType(),
                e.isStatus() ? "Activo" : "Inactivo"
            });
        }
    }

    private void agregarEntidad() {

        JTextField txtCode = new JTextField();
        JTextField txtName = new JTextField();
        JTextField txtAddress = new JTextField();
        JTextField txtPhone = new JTextField();

        JComboBox<String> cbType
                = new JComboBox<>(
                        new String[]{
                            "generadora",
                            "operadora"
                        }
                );

        JCheckBox chkStatus
                = new JCheckBox("Activo");

        Object[] campos = {
            "Código:", txtCode,
            "Nombre:", txtName,
            "Dirección:", txtAddress,
            "Teléfono:", txtPhone,
            "Tipo:", cbType,
            "Estado:", chkStatus
        };

        int op = JOptionPane.showConfirmDialog(
                this,
                campos,
                "Agregar Empresa",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (op == JOptionPane.OK_OPTION) {

            Entity e = new Entity();

            e.setCode(txtCode.getText().trim());
            e.setName(txtName.getText().trim());
            e.setAddress(txtAddress.getText().trim());
            e.setPhone(txtPhone.getText().trim());

            e.setType(
                    cbType.getSelectedItem().toString()
            );

            e.setStatus(
                    chkStatus.isSelected()
            );

            if (entityDAO.insertEntity(e)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Empresa agregada correctamente."
                );

                cargarEntidades();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo agregar la empresa."
                );
            }
        }
    }

    private void modificarEntidad() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione una empresa."
            );

            return;
        }

        long id = (long) modelo.getValueAt(fila, 0);

        Entity e = entityDAO.findById(id);

        if (e == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No se encontró la empresa."
            );

            return;
        }

        JTextField txtCode
                = new JTextField(e.getCode());

        JTextField txtName
                = new JTextField(e.getName());

        JTextField txtAddress
                = new JTextField(e.getAddress());

        JTextField txtPhone
                = new JTextField(e.getPhone());

        JComboBox<String> cbType
                = new JComboBox<>(
                        new String[]{
                            "generadora",
                            "operadora"
                        }
                );

        cbType.setSelectedItem(e.getType());

        JCheckBox chkStatus
                = new JCheckBox(
                        "Activo",
                        e.isStatus()
                );

        Object[] campos = {
            "Código:", txtCode,
            "Nombre:", txtName,
            "Dirección:", txtAddress,
            "Teléfono:", txtPhone,
            "Tipo:", cbType,
            "Estado:", chkStatus
        };

        int op = JOptionPane.showConfirmDialog(
                this,
                campos,
                "Modificar Empresa",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (op == JOptionPane.OK_OPTION) {

            e.setCode(txtCode.getText().trim());
            e.setName(txtName.getText().trim());
            e.setAddress(txtAddress.getText().trim());
            e.setPhone(txtPhone.getText().trim());

            e.setType(
                    cbType.getSelectedItem().toString()
            );

            e.setStatus(
                    chkStatus.isSelected()
            );

            if (entityDAO.updateEntity(e)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Empresa actualizada correctamente."
                );

                cargarEntidades();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo actualizar la Empresa."
                );
            }
        }
    }

    private void eliminarEntidad() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione una empresa."
            );

            return;
        }

        long id = (long) modelo.getValueAt(fila, 0);

        int op = JOptionPane.showConfirmDialog(
                this,
                "¿Eliminar empresa seleccionada?",
                "Confirmar",
                JOptionPane.YES_NO_OPTION
        );

        if (op == JOptionPane.YES_OPTION) {

            if (entityDAO.deleteEntity(id)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Empresa eliminada correctamente."
                );

                cargarEntidades();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo eliminar la empresa."
                );
            }
        }
    }
}
